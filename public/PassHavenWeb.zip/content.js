chrome.storage.local.get('passwords', (data) => {
  if (data.passwords) {
    const currentUrl = window.location.href;

    // Check if there's a password for the current URL
    const matchingPassword = data.passwords.find(pass => pass.url === currentUrl);

    if (matchingPassword) {
      document.querySelector('input[type="text"], input[type="email"]').value = matchingPassword.username;
      document.querySelector('input[type="password"]').value = matchingPassword.password;
    }
  }
});
